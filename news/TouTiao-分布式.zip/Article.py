#!/usr/bin/python
# -*- coding: utf-8 -*-


class Article(object):

    def __init__(self, image_url, item_id, publish_time, title, author="", content="", url="", cat=""):
        self.image_url = image_url
        self.item_id = item_id
        self.publish_time = publish_time
        self.title = title
        self.author = author
        self.content = content
        self.url = url
        self.cat = cat