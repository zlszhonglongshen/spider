#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib.request as request
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from module import UserAgent
import random
import http.cookiejar
from selenium import webdriver
import json
from module.Article import Article
import pymysql.cursors
import redis
import time
import math
import hashlib
import threading
from bs4 import BeautifulSoup
import PyV8
import requests
from pycookiecheat import chrome_cookies
from module.CookiesUtil import get_cookie_path
import re
import html


class TouTialProcessor:
    connect = None
    cursor = None

    def __init__(self):
        self.data_list = []
        self.req = None
        self.r = redis.Redis(host='localhost', port=6379, password='Terran123456')

    def init_connection(self):

        connect = pymysql.Connect(
            host='localhost',
            port=3306,
            user='root',
            passwd='123456',
            db='test',
            charset='utf8'
        )
        return connect

    def batch_save_to_db(self, articles):
        connect = self.init_connection()
        cursor = connect.cursor()
        sql = "INSERT INTO tp_toutiao_article (item_id, publish_time, title, content,url, image_url, author,cat) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
        datalist = []
        for article in articles:
            if article:
                data = (article.item_id, article.publish_time, article.title, article.content, article.url, article.image_url, article.author,article.cat)
                datalist.append(data)
        try:
            cursor.executemany(sql, datalist)
            connect.commit()
        except Exception as e:
            connect.rollback()
            print(e)
        finally:
            cursor.close()
            connect.close()

    def init_request(self, proxy_addr, url, is_debug=False):
        self.req = request.Request(url)
        inx = random.randint(0, 8)
        self.req.add_header('User-Agent', UserAgent.user_agent[inx])
        if is_debug:
            debug = 1
        else:
            debug = 0
        httphd = request.HTTPHandler(debuglevel=debug)
        httshd = request.HTTPSHandler(debuglevel=debug)
        cookies = http.cookiejar.CookieJar()
        if proxy_addr != "":
            proxy = request.proxyHandler({'http', proxy_addr})
            opener = request.build_opener(proxy, request.HTTPCookieProcessor(cookies), httphd, httshd)
        else:
            opener = request.build_opener(request.HTTPCookieProcessor(cookies), httphd, httshd)
        request.install_opener(opener)

    def get_search_result(self, keyword, page):
        keyword = request.quote(keyword)
        url = 'https://www.toutiao.com/search_content/?offset=' + str(
            (page - 1) * 20) + '&format=json&keyword=' + keyword + '&autoload=true&count=20&cur_tab=4&from=media'
        urls = []
        self.init_request("", url, False)
        data = request.urlopen(url).read()
        data = json.loads(data)
        for item in data['data']:
            if ('media_id' in item.keys()):
                full_url = item['source_url'] + '#mid=' + item['media_id']
                self.parse_article(item['media_id'],keyword)
            else:
                full_url = item['source_url']
            urls.append(full_url)
        return urls

    def parse_content(self, item):
        url = 'https://www.toutiao.com/i' + item.item_id
        is_exist = self.r.sismember(u'url', url)
        # 如何redis中已经存在爬过的url则自动跳过
        if is_exist:
            return
        browser = webdriver.Chrome()
        browser.get(url)
        browser.implicitly_wait(20)

        # titleElement = browser.find_element_by_class_name('article-title')
        try:
            content_element = browser.find_element_by_class_name('article-content')
            content = content_element.get_attribute('innerHTML')
            author = browser.find_element_by_xpath("//div[@class='article-sub']/span")
            item.content = content
            item.url = url
            item.author = author.text
            # TOTO 将已经爬过的url缓存起来后续要进行过滤
            self.r.sadd(u'url', url)
            browser.quit()
            # print(item.__dict__)
        except NoSuchElementException as e:
            # NO ELEMENT FOUND
            # e.stacktrace
            print('失败：url:%s', url)
        return item

    def parse_content_new(self, item):
        url = 'https://www.toutiao.com/i' + item.item_id
        # is_exist = self.r.sismember(u'url', url)
        # # 如何redis中已经存在爬过的url则自动跳过
        # if is_exist:
        #     return
        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
            'Connection': 'keep-alive',
            'authority': 'www.toutiao.com',
            'referer': 'https://www.toutiao.com/i'+ item.item_id+'/',
            'method': 'GET',
            'path': 'a/'+item.item_id +'/',
            'scheme': 'https'
        }
        # cookies = chrome_cookies('https://www.toutiao.com',cookie_file=get_cookie_path())
        # cookie_str = ''
        # for k in cookies:
        #     cookie_str = cookie_str + k +'='+ cookies[k]+';'
        # headers['cookie'] = cookie_str
        req = request.Request(url, headers=headers)
        resp_data = request.urlopen(req).read()
        data = resp_data.decode()
        # title = re.findall(r'title:(.+)',data)[0]
        # title = re.findall("'(.+)'",title)[0]
        content = re.findall(r"content:(.+)", data)[0]
        content = html.unescape(content)
        content = re.findall("'(.+)'", content)[0]
        author = re.findall(r'source:(.+)', data)[0]
        author = re.findall("'(.+)'", author)[0]
        item.author = author
        item.content = content
        item.url = url
        return item


    def parse_article(self, mid, keyword):
        keyword = request.unquote(keyword, 'utf-8')
        path = '/api/pc/media_hot/?media_id=' + mid
        url = 'https://www.toutiao.com/api/pc/media_hot/?media_id=' + mid
        self.init_request("", url, False)
        self.req.add_header('authority', 'www.toutiao.com')
        self.req.add_header('method', 'GET')
        self.req.add_header('path', path)
        self.req.add_header('scheme', 'https')
        data = request.urlopen(self.req).read()
        data = data.decode('unicode_escape')
        data = json.loads(data)
        articles = data['data']['hot_articles']
        articleList = []
        for article in articles:
            arc = Article(article['image_url'], article['item_id'], article['publish_time'], article['title'])
            item = self.parse_content(arc)
            if item:
                item.cat = keyword
                articleList.append(item)
        self.batch_save_to_db(articleList)

    def comprehensive_search(self, keyword, page):
        keyword = request.quote(keyword)
        path = '/search_content/?offset=' + str(
            (page - 1) * 20) + '&format=json&keyword=' + keyword + '&autoload=true&count=20&cur_tab=1&from=search_tab'
        url = 'https://www.toutiao.com/search_content/?offset=' + str(
            (page - 1) * 20) + '&format=json&keyword=' + keyword + '&autoload=true&count=20&cur_tab=1&from=search_tab'
        self.init_request("", url, False)
        self.req.add_header('authority', 'www.toutiao.com')
        self.req.add_header('method', 'GET')
        self.req.add_header('path', path)
        self.req.add_header('scheme', 'https')
        data = request.urlopen(self.req).read()
        # data = data.decode('unicode_escape')
        data = json.loads(data)
        articleList = []
        for article in data['data']:
            if 'play_effective_count' not in article.keys():
                if 'cell_type' not in article.keys():
                    arc = Article(article['image_url'], article['item_id'], article['datetime'], article['title'])
                    arc.author = article['media_name']
                    item = self.parse_content(arc)
                    item.cat = keyword
                    articleList.append(item)
        self.batch_save_to_db(articleList)

    def getASCP(self):
        t = int(math.floor(time.time()))
        e = hex(t).upper()[2:]
        m = hashlib.md5()
        m.update(str(t).encode(encoding='utf-8'))
        i = m.hexdigest().upper()

        if len(e) != 8:
            AS = '479BB4B7254C150'
            CP = '7E0AC8874BB0985'
            return AS, CP

        n = i[0:5]
        a = i[-5:]
        s = ''
        r = ''
        for o in range(5):
            s += n[o] + e[o]
            r += e[o + 3] + a[o]

        AS = 'A1' + s + e[-3:]
        CP = e[0:3] + r + 'E1'
        return AS, CP

    def parser_users_article(self, user_id, max_behot_time, cookies, headers={}):
        signature = self.get_signature(user_id, max_behot_time)
        as_str, cp_str = self.getASCP()
        req = requests.session()
        payload = {"user_id": user_id, "max_behot_time": max_behot_time, "as": as_str, "cp": cp_str, "_signature": signature}
        url = 'https://www.toutiao.com/c/user/article/?page_type=1&count=200'
        path = "/c/user/article/?page_type=1&user_id=" + str(user_id)+"&max_behot_time=" + str(max_behot_time)+"&count=20&as=" + as_str+"&cp=" + cp_str + "&_signature="+signature
        if not any(headers):
            _headers = {
                'authority': 'www.toutiao.com',
                'method': 'GET',
                'path': path,
                'scheme': 'https',
                'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
                'x-requested-with': 'XMLHttpRequest',
                'content-type': 'application/x-www-form-urlencoded'
            }
        else:
            _headers = headers
        ip, port = ('183.62.196.10', '3128')
        proxy_url = "https://{0}:{1}".format(ip, port)
        proxy_dict = {
            "http": proxy_url
        }
        if not cookies:
            resp = req.get(url, params=payload, headers=_headers,proxies=proxy_dict)
        else:
            resp = req.get(url, params=payload, headers=_headers, cookies=cookies, proxies=proxy_dict)
        content = resp.content.decode()
        data = json.loads(content)
        if len(data['data']) > 0:
            self.data_list.append(data['data'])
        # if data['has_more'] == True :
        #     _headers['referer'] = 'https://www.toutiao.com/c/user/' + str(user_id) +'/'
        #     self.parser_users_article(user_id, data['next']['max_behot_time'], resp.cookies, _headers)

    def get_signature(self, user_id, hottime):
        user_id = str(user_id) + "" + str(hottime)
        url = 'https://s3.pstatp.com/toutiao/resource/ntoutiao_web/page/profile/index_591a490.js'
        req = requests.Session()
        resp = req.get(url, headers={})
        js = resp.content
        content = js.decode()
        effectjs = content.split(",Function")
        exjs = 'var navigator = {};\
            navigator["userAgent"]= "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36"; \
        ' + 'Function' + effectjs[1] + ";function result(){ return TAC.sign(" + user_id + ");} result();"
        ctx = PyV8.JSContext()
        with PyV8.JSLocker():
            ctx.enter()
            signature = ctx.eval(exjs)
            ctx.leave()

        return signature





if __name__ == '__main__':
    toutiao = TouTialProcessor()
    # toutiao.login("", "https://sso.toutiao.com/quick_login/", True)
    # toutiao.process("", "https://www.toutiao.com/a6583058110909252103")
    # toutiao.dynamicParse('https://www.toutiao.com/a6583058110909252103')
    # search_thread = threading.Thread(target=toutiao.get_search_result, args=(u'商业模式',1))
    # comprehensive_thread = threading.Thread(target=toutiao.comprehensive_search, args=('销售话术', 1))
    # toutiao.get_search_result(u'商业模式', 1)
    # toutiao.comprehensive_search('销售话术', 1)
    # toutiao.init_connection()
    # toutiao.orgin_parse('https://www.toutiao.com/c/user/71147805585/#mid=1588553395829774')
    # toutiao.parse_signture(71147805585, 0)
    # AS,CP = toutiao.getASCP()
    # print(AS,CP)
    # toutiao.parser_users_article(71147805585, 0, None)
    # print(len(toutiao.data_list))
    # sig = toutiao.get_signature(71147805585,1522385633)
    # print(sig)

    toutiao.parse_content_new('6603143834966688259')