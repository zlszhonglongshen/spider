# coding:utf-8
import re
def getvalue(direct):
    return direct["freq"]
a = []
for i in range(1,11):
    filename = 'D:/ss/newscn/%d.txt' % (i)
    file = a.append(filename)
    # print filename

# print str(a)
b = []
lists=[]
for n in a:
    print n
    file_ = open(n).read().decode("utf-8")
    # print file_
    freq = len(re.findall("自然语言处理",file_.encode("utf-8")))
    print freq # 单个文档的关键词词频
    # file.close()
    dir={"file_dir":n,"freq":freq}
    lists.append(dir)
    freq_ = b.append(freq)
#print lists[0]
lists.sort(key=getvalue,reverse=True)
print lists



# txt = 'xxhello danh但是ello但是sdfsd但是hf速度'
# list = re.findall("但是", txt)
# print len(list)
