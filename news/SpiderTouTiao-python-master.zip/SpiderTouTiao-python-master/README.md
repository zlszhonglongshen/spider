# SpiderTouTiao-python
Spiders for JinRITouTiao 

在今日头条上输入关键词，爬取与关键词相关的新闻各类信息和内容页;

spiders/JinRiTouTiao.py使用了scrapy+Selenium +phantomjs爬取;

spiders/toutiao.py使用了scrapy+urllib+lxml爬取.
