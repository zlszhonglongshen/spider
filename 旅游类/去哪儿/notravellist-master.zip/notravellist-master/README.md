# notravellist
功能包含：
- 爬取输入区域的景点名称、地址、销量、售价等信息并存入excel表格。
- 根据景点位置获取景点经纬度等信息生成与百度地图api、echarts示例对接的json文件
- 对百度地图api、echarts进行修改可引入本地json文件
