# danshengoustyle
- 知乎爬虫
```
.
└── zhihu.com
    ├── studyxjj
    └── zhihuxjj
```
zhihuxjj一个scrapy框架写成的爬虫，配置mysql数据库后，运行main.py文件即可。
studyxjj分析单个用户动态。

个人公众号：大吉大利小米酱

如需交流请加入python交流群：613176398
